wget https://github.com/microsoft/WSL2-Linux-Kernel/archive/refs/tags/linux-msft-wsl-5.15.150.1.zip
unzip linux-msft-wsl-5.15.150.1.zip
rm linux-msft-wsl-5.15.150.1.zip
mv WSL2-Linux-Kernel-linux-msft-wsl-5.15.150.1 WSL2-Linux-Kernel 

sudo apt update

export _pkgbase=dxgkrnl
export pkgver=5.6.rc2.r77380.g918dbaa9fa4a
export pkgdir=""

mkdir -p "${pkgdir}"/usr/src/${_pkgbase}-${pkgver}/
cp -r WSL2-Linux-Kernel/drivers/hv/dxgkrnl/* "${pkgdir}"/usr/src/${_pkgbase}-${pkgver}/
cp WSL2-Linux-Kernel/include/uapi/misc/d3dkmthk.h "${pkgdir}"/usr/src/${_pkgbase}-${pkgver}/
sed -e "s/<uapi\/misc\/d3dkmthk.h>/\"d3dkmthk.h\"/" \
      -i "${pkgdir}"/usr/src/${_pkgbase}-${pkgver}/dxgkrnl.h
# patch --ignore-whitespace -d "${pkgdir}"/usr/src/${_pkgbase}-${pkgver} < fix_recv.patch
install -Dm644 dkms.conf "${pkgdir}"/usr/src/${_pkgbase}-${pkgver}/dkms.conf
sed -e "s/@_PKGBASE@/${_pkgbase}/" \
      -e "s/@PKGVER@/${pkgver}/" \
      -i "${pkgdir}"/usr/src/${_pkgbase}-${pkgver}/dkms.conf

install -Dm644 extra-defines.h "${pkgdir}"/usr/src/${_pkgbase}-${pkgver}/extra-defines.h

sudo apt install -y dkms

cd /usr/src
dkms build ./${_pkgbase}-${pkgver}

krnl_ver=`uname -r`

dkms install dxgkrnl/5.6.rc2.r77380.g918dbaa9fa4a
modprobe dxgkrnl

sudo add-apt-repository ppa:kisak/kisak-mesa
sudo apt install -y mesa-utils

echo "export LIBVA_DRIVER_NAME=d3d12" > /etc/profile.d/d3d.sh
echo "export MESA_LOADER_DRIVER_OVERRIDE=vgem" >> /etc/profile.d/d3d.sh

echo "DONE"
